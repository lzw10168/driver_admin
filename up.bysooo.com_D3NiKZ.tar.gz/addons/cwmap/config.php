<?php

return [
    [
        'name' => 'baiduak',
        'title' => '访问应用(AK)<br>(<a href="http://lbsyun.baidu.com/jsdemo.htm"  target="_blank">参考文档</a>)',
        'type' => 'string',
        'content' => [],
        'value' => 'SsGqP90kmo1QkNyh9LHGrYAbBcu8hNw2',
        'rule' => 'required',
        'msg' => '',
        'tip' => '设置了正确的ak才能使用地图api',
        'ok' => '',
        'extend' => '',
    ],
];
