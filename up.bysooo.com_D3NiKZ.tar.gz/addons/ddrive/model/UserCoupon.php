<?php

namespace addons\ddrive\model;

use think\Model;


class UserCoupon extends Model
{
    // 表名
    protected $name = 'user_coupon';

}
