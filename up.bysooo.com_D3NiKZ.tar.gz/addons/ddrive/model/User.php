<?php
/**
 * User.php
 * @des
 * Created by PhpStorm.
 * Date: 2020/12/2
 * Time: 17:57
 */

namespace addons\ddrive\model;

use think\Model;

class User extends Model
{

}