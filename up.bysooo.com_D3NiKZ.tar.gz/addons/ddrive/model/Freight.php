<?php
/**
 * User.php
 * @des
 * Created by PhpStorm.
 * Date: 2020/12/2
 * Time: 17:57
 */

namespace addons\ddrive\model;

use think\Model;

class Freight extends Model
{
// 表名
    protected $name = 'ddrive_hy_freight';
}